/**
 * @file	main.cpp
 * @brief	Codigo fonte com a funçao principal do projeto
 * @author	Wanderson Alves de Oliveira (wanderson.alves@live.com)
 */

#include <iostream>

using std::cin;
using std::cout;
using std::endl;

#include "primalidade.h"
#include "fatorial.h"

int main(){
	int x, aux;
	cout << "digite o numero a ser analisado" << endl;
	cin >> x;
	aux = fatorial(x);
	cout << "o fatorial é: " << aux << endl;
	primalidade(aux);	
	return 0;
}


