/**
 * @file	fatorial.cpp
 * @brief	Codigo fonte com a implementacao de funcao que calcula fatorial
 * @author	Wanderson Alves de Oliveira (wanderson.alves@live.com)
 */

#include "fatorial.h"

#include<iostream>

using namespace std;

/**
 * @brief Calcula o valor do fatorial
 * @param X numero utilizado no calculo
 * @return Valor do fatorial do numero
 */
double fatorial(double x){
   double aux;
   aux = x;
   while(x > 1){
      aux = aux * (x-1);
      x--;
   }
   return (aux);
}

