/**
 * @file	primalidade.cpp
 * @brief	Codigo fonte com a implementacao de funcao que verifica se o numero e primo
 * @author	Wanderson Alves de Oliveira (wanderson.alves@live.com)
 */

#include "primalidade.h"

#include<iostream>

using namespace std;

/**
 * @brief verifica se um numero e primo
 * @param X numero a ser utilizado
 * @return se o numero e primo ou nao
 */
void primalidade(int x){
	int aux = 2; 		
	int div = 0;
	//while(div!=2){ 
		while(aux<=x/2){
			if((x%aux)==0){
				div++;
			}
			aux++;
		}
		
		if (div == 0){
			cout << x << " é primo" << endl;
		}
		else{
			cout << x << " não é primo" << endl;
		}
		//x--;
	//}
	//cout << x << "é primo" << endl;
}
