#ifndef PRIMALIDADE_H
#define PRIMALIDADE_H

#include<iostream>

using namespace std;

/**
 * @brief verifica se um numero e primo
 * @param X numero a ser utilizado
 * @return se o numero e primo ou nao
 */
void primalidade(int x);

#endif
