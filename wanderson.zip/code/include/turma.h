#ifndef _TURMA_H_
#define _TURMA_H_

#include "aluno.h"
#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cstdlib> 

using namespace std;

class Turma : public Aluno
{
private:
	std::vector<AlunoTurma*> alunos;
public:
	Turma();
	~Turma();
	int addAluno(AlunoTurma aluno);
	Aluno* buscaAlunoPorNome (std::string nome);
	Aluno* buscaAlunoPorMatricula (std::string matricula);
	int removeAlunoPorNome (std::string nome);
	int removeAlunoPorMatricula (std::string matricula);
	void listaAlunos();
};

#endif
