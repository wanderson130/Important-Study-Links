#ifndef _ALUNO_H_
#define _ALUNO_H_

#include <string>

class Aluno {
private:
	std::string matricula;
	std::string nome;
	int faltas;
	double nota;
public:
	Aluno();
	Aluno(std::string _matricula, std::string _nome);
	
	void setNome(std::string nome){this->nome = nome;}
	std::string getNome(){return this->nome;}

	void setMatricula(std::string matricula){this->matricula = matricula;}
	std::string getMatricula(){return this->matricula;}
	
	void setFaltas(int faltas){this->faltas = faltas;}
	int getFaltas(){return this->faltas;}

	void setNota(double nota){this->nota = nota;}
	int getNota(){return this->nota;}
};

class AlunoTurma {
private:
	Aluno* discente;
	int faltas;
	double nota;
public:
	AlunoTurma();
	AlunoTurma(Aluno* _discente, int _faltas, double _nota);
	Aluno* getDiscente();
};

#endif
