#ifndef _ALUNO_H_
#define _ALUNO_H_

#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cstdlib> 

using namespace std;

class Aluno {
private:
	std::string matricula;
	std::string nome;
	int faltas;
	double nota;

public:
	Aluno();
	Aluno(std::string matricula, std::string nome);
	
	void setNome(std::string nome){this->nome = nome;}
	std::string getNome(){return this->nome;}

	void setMatricula(std::string matricula){this->matricula = matricula;}
	std::string getMatricula(){return this->matricula;}
	
	void setFaltas(int faltas){this->faltas = faltas;}
	int getFaltas(){return this->faltas;}

	void setNota(double nota){this->nota = nota;}
	int getNota(){return this->nota;}
};

class AlunoTurma : public Aluno {
private:
	Aluno* discente;
	int faltas;
	double nota;
public:
	AlunoTurma();
	AlunoTurma(Aluno* discente, int faltas, double nota);
	Aluno* getDiscente();

	void setFaltas(int faltas){this->faltas = faltas;}
	int getFaltas(){return this->faltas;}
	
	void setNota(double nota){this->nota = nota;}
	int getNota(){return this->nota;}
};

#endif
