#include <iostream>
#include "turma.h"

Turma::Turma() {}

Turma::~Turma() {}

void TratarLeitura(int& leitura)
{	
	cin.exceptions(ios_base::failbit);

	try
	{
		cin >> leitura;
	}
	catch( const ios_base::failure& e )
	{
		cout << "\nException: " << e.what() << endl;
		cout << "Voce deve digitar um Numero inteiro.\n";
	}
}

int 
Turma::addAluno(AlunoTurma _aluno) {
	int i, n, quant;
	cout << "Informe quantos Funcionarios voce quer cadastrar:";
	cin >> quant;
	string nome;
    
    for(i = 0; i < quant; i++) {
  		Alunos *informacoes = new Alunos();
		    		
		    	cout << "Informe o nome do Funcionario: ";
			cin.ignore(0);    
		    	getline(cin, nome);
		    	informacoes->setNome(nome);

		    	cout << "Infome a matricula do Aluno: ";
		    	TratarLeitura(n);
		    	informacoes->setMatricula(n);
				
			cout << "Infome o número de faltas do aluno: ";
		    	TratarLeitura(n);
		    	informacoes->setFaltas(n); 	

			cout << "Infome a nota do aluno: ";
		    	TratarLeitura(n);
		    	informacoes->setNota(n);  			

		    	cout << "\n";  	

		alunos.push_back(informacoes);
	}
	return -1;
}

Aluno* 
Turma::buscaAlunoPorNome (std::string _nome) {
	for(int i = 0; i < alunos.size(); i++){
		if( nome == alunos[i]->getNome()){
			cout << "		 ------------------------\n";
			cout << "		| Aluno Encontrado |\n";
			cout << " 		 ------------------------\n\n";
	       		cout << setw(20) << left <<  "Nome:"  				 << "\t" << alunos[i]->getNome() << endl;
	        	cout << setw(20) << left <<  "Matricula:" 			 << "\t" << alunos[i]->getMatricula() << endl;
	        	cout << setw(20) << left <<  "Faltas:"		 		 << "\t" << alunos[i]->getFaltas() << endl;
	        	cout << setw(20) << left <<  "Nota:" 				 << "\t" << alunos[i]->getNota() << endl;
			cout << setw(20) << left <<  "-----------------------------" << endl;  
			break;
		}
	}
	return NULL;
}

Aluno* 
Turma::buscaAlunoPorMatricula (std::string _matricula) {
	for(int i = 0; i < alunos.size(); i++)
	{
		if( matricula == alunos[i]->getMatricula())
		{
			return i;
		}
	}
	return NULL;
}

void 
Turma::listaAlunos() {
	// Função para atualizar o arquivo já existente
	for( int i = 0; i < (int)alunos.size(); i++ )
		{
			cout << "		 ------------------------\n";
			cout << "		| Aluno Encontrado |\n";
			cout << " 		 ------------------------\n\n";
	       		cout << setw(20) << left <<  "Nome:"  				 << "\t" << alunos[i]->getNome() << endl;
	        	cout << setw(20) << left <<  "Matricula:" 			 << "\t" << alunos[i]->getMatricula() << endl;
	        	cout << setw(20) << left <<  "Faltas:"		 		 << "\t" << alunos[i]->getFaltas() << endl;
	        	cout << setw(20) << left <<  "Nota:" 				 << "\t" << alunos[i]->getNota() << endl;
			cout << setw(20) << left <<  "-----------------------------" << endl;  
			break;
		}
// Mostra na tela o arquivo constendo todos os funcionario
}

int 
Turma::removeAlunoPorNome (std::string _nome) {
	/* Remove o aluno com o nome indicado.
	   Retorna 0 caso o aluno seja encontrado e removido com sucesso.
	   Retorna -1 em caso contrário.
	   Dica: Para remover um elemento do vetor, utilize o metodo erase().
	*/
	return -1;
}

int 
Turma::removeAlunoPorMatricula (std::string _matricula) {
    /* Remove o aluno com a matricula indicada.
	   Retorna 0 caso o aluno seja encontrado e removido com sucesso.
	   Retorna -1 em caso contrário.
	   Dica: Para remover um elemento do vetor, utilize o metodo erase().
	*/
	return -1;
}
