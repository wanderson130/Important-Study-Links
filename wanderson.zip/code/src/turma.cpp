#include <iostream>
#include "turma.h"

Turma::Turma() {}

Turma::~Turma() {}

void TratarLeitura(int& leitura){	
	cin.exceptions(ios_base::failbit);

	try{
		cin >> leitura;
	}
	catch( const ios_base::failure& e ){
		cout << "\nException: " << e.what() << endl;
		cout << "Voce deve digitar um Numero inteiro.\n";
	}
}

int 
Turma::addAluno(AlunoTurma aluno) {
	int i, n, quant;
	cout << "Informe quantos Funcionarios voce quer cadastrar:";
	cin >> quant;
	string nome;
    
    for(i = 0; i < quant; i++) {
  		AlunoTurma *informacoes = new AlunoTurma();
		    		
		    cout << "Informe o nome do Funcionario: ";
			    cin.ignore(0);    
		    	getline(cin, nome);
		    	informacoes->setNome(nome);

		    cout << "Infome a matricula do Aluno: ";
		    	TratarLeitura(n);
				getline(cin, nome);
		    	informacoes->setMatricula(nome);
				
			cout << "Infome o número de faltas do aluno: ";
		    	TratarLeitura(n);
		    	informacoes->setFaltas(n); 	

			cout << "Infome a nota do aluno: ";
		    	TratarLeitura(n);
		    	informacoes->setNota(n);  			

		    	cout << "\n";  	

		alunos.push_back(informacoes);
	}
	return -1;
}

Aluno* 
Turma::buscaAlunoPorNome (std::string nome) {
	for(unsigned i = 0; i < alunos.size(); i++){
		if( nome == alunos[i]->getNome()){
			cout << "		 ------------------------\n";
			cout << "		| Aluno Encontrado |\n";
			cout << " 		 ------------------------\n\n";
	       		cout << setw(20) << left <<  "Nome:"  				 << "\t" << alunos[i]->getNome() << endl;
	        	cout << setw(20) << left <<  "Matricula:" 			 << "\t" << alunos[i]->getMatricula() << endl;
	        	cout << setw(20) << left <<  "Faltas:"		 		 << "\t" << alunos[i]->getFaltas() << endl;
	        	cout << setw(20) << left <<  "Nota:" 				 << "\t" << alunos[i]->getNota() << endl;
			cout << setw(20) << left <<  "-----------------------------" << endl;  
			break;
		}
	}
	return NULL;
}

Aluno* 
Turma::buscaAlunoPorMatricula (std::string matricula) {
	for(unsigned i = 0; i < alunos.size(); i++){
		if( matricula == alunos[i]->getMatricula()){
			cout << "		 ------------------------\n";
			cout << "		| Aluno Encontrado |\n";
			cout << " 		 ------------------------\n\n";
	       		cout << setw(20) << left <<  "Nome:"  				 << "\t" << alunos[i]->getNome() << endl;
	        	cout << setw(20) << left <<  "Matricula:" 			 << "\t" << alunos[i]->getMatricula() << endl;
	        	cout << setw(20) << left <<  "Faltas:"		 		 << "\t" << alunos[i]->getFaltas() << endl;
	        	cout << setw(20) << left <<  "Nota:" 				 << "\t" << alunos[i]->getNota() << endl;
			cout << setw(20) << left <<  "-----------------------------" << endl;  
			break;
		}
	}
	return NULL;
}

void 
Turma::listaAlunos() {
	// Função para atualizar o arquivo já existente
	for(unsigned i = 0; i < alunos.size(); i++ ){
			cout << "		 ------------------------\n";
			cout << "		| Aluno Encontrado |\n";
			cout << " 		 ------------------------\n\n";
	       		cout << setw(20) << left <<  "Nome:"  				 << "\t" << alunos[i]->getNome() << endl;
	        	cout << setw(20) << left <<  "Matricula:" 			 << "\t" << alunos[i]->getMatricula() << endl;
	        	cout << setw(20) << left <<  "Faltas:"		 		 << "\t" << alunos[i]->getFaltas() << endl;
	        	cout << setw(20) << left <<  "Nota:" 				 << "\t" << alunos[i]->getNota() << endl;
			cout << setw(20) << left <<  "-----------------------------" << endl;  
			break;
		}
}

int 
Turma::removeAlunoPorNome (std::string nome) {
	for(unsigned i = 0; i < alunos.size(); i++){
		if(nome == alunos[i]->getNome()){
			alunos.erase(alunos.begin()+i);
			cout << "Aluno: " << nome << " ,encontrado e removido" << endl;
			return 0;
			}
		}		
	return -1;
}

int 
Turma::removeAlunoPorMatricula (std::string matricula) {
	for(unsigned i = 0; i < alunos.size(); i++){
		if(matricula == alunos[i]->getMatricula()){
			alunos.erase(alunos.begin()+i);
			cout << "Aluno de matricula: " << matricula << " ,encontrado e removido" << endl;
			return 0;
			}
		}		
	return -1;
}
