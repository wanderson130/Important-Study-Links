package professor;
import java.util.ArrayList;
import java.util.Iterator;

public class ProfessorHorista {
    private int total_horas;
    private String salario_hora;
           
    public ProfessorHorista(int _total_horas,String _salario_hora){
        total_horas = _total_horas;
        salario_hora = _salario_hora;
    }

    public void setTotalHoras(int total_horas){this.total_horas = total_horas;}
    public int getTotalHoras(){return total_horas;}
    
    public void setSalarioHora(String salario_hora){this.salario_hora = salario_hora;}
    public String getSalarioHora(){return salario_hora;}
    
    public void print(){
        System.out.println(" " + total_horas);
        System.out.println(" " + salario_hora);
    }
}
