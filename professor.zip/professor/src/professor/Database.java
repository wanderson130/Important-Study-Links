package professor;
import java.util.ArrayList;
import java.util.Iterator;

public class Database{
    private ArrayList<Professor> professores;
    
    public Database(){
        professores = new ArrayList<Professor>();
    }
    
    public void addProfessor(Professor _professor){
        professores.add(_professor);
    }
    
    public void list(){
        for(Professor professor : professores)
        professor.print();
        System.out.println(); //barra n
    }
}
