/** @author wanderson.alves
 */
package professor;

import java.util.ArrayList;
import java.util.Iterator;

public class Professor {
    private String nome;
    private String matricula;
    private int idade;

    public Professor(){}
    public Professor(String _nome, String _matricula, int _idade) {
	nome = _nome;
	matricula = _matricula;
	idade = _idade;
    }

    public void setNome(String nome){this.nome = nome;}
    public String getNome(){return nome;}

    public void setMatricula(String matricula){this.matricula = matricula;}
    public String getMatricula(){return matricula;}
   
    public void setIdade(int idade){this.idade = idade;}
    public String getIdade(){return idade;}
}