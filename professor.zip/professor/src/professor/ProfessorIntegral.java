package professor;
import java.util.ArrayList;
import java.util.Iterator;

public class ProfessorIntegral extends Professor {
    private double salario;
    
    public ProfessorIntegral(String nome, String matricula, int idade, double _salario){
        super(nome, matricula, idade);
        salario = _salario;
    }
  
    public void setSalario(double salario){this.salario = salario;}
    public double getSalario(){return salario;}
    
    public void print(){
        System.out.println(" " + salario);
    }
}
