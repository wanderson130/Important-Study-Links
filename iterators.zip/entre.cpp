#include <algorithm>
using std::find_if;
#include <iostream>
using std::cout;
using std::endl;
#include <vector>
using std::vector;

// Definindo uma funcao a ser usada como predicado
// Definindo o Functor Entre
class Entre
{
int menor, maior;
public:
Entre(int n, int m):menor(n), maior(m) {}
bool operator()(int n) const { return (n >= menor and n <= maior); }
};

int main() {
// Vetor de inteiros
vector<int> valores { 2, 44, 56, 13, 88, 78, 90, 3, 4, 5 };

// Encontra a primeira ocorrência entre 12 e 57 usando uma functor como predicado
auto it = find_if(valores.begin(), valores.end(), Entre(12,57));
if (it != valores.end()) {
cout << "Primeiro valor: " << (*it) << endl;
} else {
cout << "Nao ha valores que satisfacam o predicado. " << endl;
}
return 0;
}
