#include <algorithm>
using std::count;
using std::find;
using std::for_each;
#include <iostream>
using std::cout;
using std::endl;
#include <string>
using std::string;
#include <vector>
using std::vector;
void imprime(string nome, int ) {
cout << nome << " ";
}

int main() {
// Vetor de strings com quatro elementos (exclusivamente em C++11)
vector<string> nomes = { "Maria", "Joao", "Mauricio", "Joao" };
// Conta o numero de ocorrencias de "Joao" no vetor


int ocorrencias = count(nomes.begin(), nomes.end(), "Joao");

cout << "Foram encontradas " << ocorrencias << " ocorrencias no vetor" << endl;
// Encontra a primeira ocorrência de "Joao" no vetor
vector<string>::iterator it = find(nomes.begin(), nomes.end(), "Joao");
if (it == nomes.end()) {
cout << "String nao encontrada" << endl;
}

// Chama a funcao imprime para cada elemento do vetor
for_each(nomes.begin(), nomes.end(), imprime );
return 0;
}
