#include <algorithm>
using std::fill;
using std::random_shuffle;
using std::replace;
using std::reverse;
#include <iostream>
using std::cout;
using std::endl;
#include <vector>
using std::vector;
void imprime(vector<int> v) {
// Funcao para imprimir os elementos de um vetor
vector<int>::iterator i;
for (i = v.begin(); i != v.end(); ++i) {
cout << *i << " ";
}
cout << endl;
}

int main() {
vector<int> numeros;
for (int i = 1; i <= 10; i++) numeros.push_back(i);
// Vetor de inteiros vazio
// Insercao de elementos no vetor
reverse(numeros.begin(), numeros.end());
imprime(numeros); // Inverte a ordem dos elementos
random_shuffle(numeros.begin(), numeros.end());
imprime(numeros); // Reordena aleatoriamente os elementos
replace(numeros.begin(), numeros.end(), 10, 100); // Substitui a ocorrencia de um valor
imprime(numeros);
fill(numeros.begin(), numeros.end(), 0);
imprime(numeros);
return 0;
}
// Preenche todos os elementos do vetor com 0
